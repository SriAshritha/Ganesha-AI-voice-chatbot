# import base64
# import os
# import streamlit as st
# import streamlit.components.v1 as components
# import speech_recognition as sr
# from openai import OpenAI
# from gtts import gTTS
# import tempfile
# import requests
# import base64
# import librosa
# from pydub import AudioSegment
# from pydub.effects import speedup
# import tempfile


# import librosa, soundfile as sf

# def cartoonify_librosa(path_in, semitones=5):
#     y, sr = librosa.load(path_in, sr=None)
#     y_shifted = librosa.effects.pitch_shift(y, sr=sr, n_steps=semitones)
#     tmp_out = tempfile.NamedTemporaryFile(suffix=".wav", delete=False).name
#     sf.write(tmp_out, y_shifted, sr)
#     return AudioSegment.from_wav(tmp_out)


# # # Analyze user voice
# def analyze_user_voice(file_path):
#     y, sr = librosa.load(file_path)
#     pitches, magnitudes = librosa.piptrack(y=y, sr=sr)
#     pitch_values = pitches[magnitudes > 0]
#     avg_pitch = pitch_values.mean() if len(pitch_values) > 0 else 0

#     onset_env = librosa.onset.onset_strength(y=y, sr=sr)
#     tempo = librosa.beat.tempo(onset_envelope=onset_env, sr=sr)[0]
#     return avg_pitch, tempo

# # Adjust TTS audio to roughly match user tempo
# def adjust_tts_pitch_speed(tts_path, user_pitch, user_tempo):
#     audio = AudioSegment.from_file(tts_path)
#     original_tempo = 120  # assumed default
#     speed_ratio = user_tempo / original_tempo if original_tempo > 0 else 1.0
#     audio = speedup(audio, playback_speed=speed_ratio)
#     # Note: pitch shift requires more advanced library like pyrubberband
#     return audio


# def get_voices(api_key):
#     url = "https://os.gan.ai/v1/voices"
#     headers = {"ganos-api-key": api_key}
#     response = requests.get(url, headers=headers)
#     response.raise_for_status()
#     return response.json().get("data", [])

# # ----------------------------
# # Page setup
# # ----------------------------
# st.set_page_config(page_title="3D Ganesha Voice Chatbot", page_icon="🕉️", layout="wide")
# st.title("🕉️ 3D Lord Ganesha • Voice Chatbot")
# st.caption("Type or speak to Ganesha. He replies with text and a deep, hoarse voice — and the 3D model animates while speaking.")

# GAN_AI_API_KEY ="tGYdQHlYNZFe8qpCFNUeG4z-bz7XQJTsFdx53w5v"

# try:
#     voices = get_voices(GAN_AI_API_KEY)
#     voice_options = {v['voice_name']: v['voice_id'] for v in voices}
# except Exception as e:
#     st.sidebar.error(f"Failed to fetch voices: {e}")
#     voices = []
#     voice_options = {}



# # ----------------------------
# # Sidebar controls
# # ----------------------------
# st.sidebar.header("Settings")
# api_key = st.sidebar.text_input("OpenRouter API Key", type="password", help="Your key is only used locally in this app.")
# model_text = st.sidebar.text_input("Text Model", value="gpt-4o-mini", help="Model used for text generation.")
# model_tts = st.sidebar.text_input("TTS Model", value="gpt-4o-mini-tts", help="Model used for speech generation.")
# if voice_options:
#     voice_name = st.sidebar.selectbox("TTS Voice", options=list(voice_options.keys()), index=0)
# else:
#     voice_name = st.sidebar.text_input("TTS Voice", value="Myna-mini")

# style_prompt = st.sidebar.text_input(
#     "Voice Style",
#     value="Speak like a gentle, wise cartoon deity, warm and playful, as if from an animated movie. Deep, hoarse, and loving tone.",
# )

# st.sidebar.markdown("---")
# model_url = st.sidebar.text_input(
#     "3D Model URL (.glb/.gltf)",
#     value="",
#     help=(
#         "Paste a direct URL to a Lord Ganesha GLB/GLTF model. "
#         "You can also embed any other GLB if you don't have one yet."
#     ),
# )
# auto_rotate = st.sidebar.checkbox("Auto-rotate model", True)
# camera_controls = st.sidebar.checkbox("Camera controls", True)

# st.sidebar.markdown("---")
# st.sidebar.write("**Tip:** Keep this window focused for audio to autoplay.")

# # Guard for API key
# if not api_key:
#     st.info("Enter your OpenRouter API key in the sidebar to start.")

# # ----------------------------
# # OpenRouter / OpenAI client
# # ----------------------------
# client = None
# if api_key:
#     client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=api_key)

# # ----------------------------
# # Chat state
# # ----------------------------
# if "history" not in st.session_state:
#     st.session_state.history = []  # list of (role, content)

# # ----------------------------
# # Helpers
# # ----------------------------
# def generate_reply(prompt: str) -> str:
#     """LLM text generation via OpenRouter"""
#     assert client is not None
#     resp = client.chat.completions.create(
#         model=model_text,
#         messages=[
#             {
#                 "role": "system",
#                 "content": (
#                     "You are Lord Ganesha, a wise, gentle, and benevolent deity."
#                     "Listen carefully to the user words, understand their intentions, and respond with warmth, guidance, and insight inspired by"
#                     "Ganesha philosophies, stories, and cultural symbolism."
#                     "Speak in a deep, hoarse, gravelly tone, warm and comforting,"
#                     "like a gentle deity guiding a devotee, giving practical, concise, and divine advice that blesses and enlightens the seeker."
#                 ),
#             },
#             {"role": "user", "content": prompt},
#         ],
#     )
#     return resp.choices[0].message.content


# def tts_bytes(text: str, voice_id: str, style_prompt: str = "") -> bytes:
#     url = "https://os.gan.ai/v1/tts"
#     headers = {
#         "Content-Type": "application/json",
#         "ganos-api-key": GAN_AI_API_KEY
#     }
#     body = {
#         "voice_id": voice_id,
#         "text": text,
#         "style": style_prompt  # pass the style here
#     }
#     response = requests.post(url, headers=headers, json=body)
    
#     print(f"Status code: {response.status_code}")
#     print(f"Response body: {response.text}")
    
#     response.raise_for_status()
#     return response.content




# def html_3d_with_audio(model_src: str, audio_b64: str, auto_rotate: bool, camera_controls: bool) -> str:
#     ar = "auto-rotate" if auto_rotate else ""
#     cc = "camera-controls" if camera_controls else ""

#     return f"""
# <!DOCTYPE html>
# <html>
# <head>
#   <meta charset="utf-8" />
#   <meta name="viewport" content="width=device-width, initial-scale=1" />
#   <script type="module" src="https://unpkg.com/@google/model-viewer/dist/model-viewer.min.js"></script>
#   <style>
#     body {{
#       margin: 0;
#       background: #0b0b10;
#       display: flex;
#       justify-content: center;
#       align-items: center;
#       height: 100vh; /* full viewport height */
#       overflow: hidden;
#     }}
#     .container {{
#       display: flex;
#       flex-direction: column;
#       align-items: center;
#       justify-content: center;
#       width: 100%;
#       max-width: 600px;
#       height: 600px;
#       padding: 20px;
#       box-sizing: border-box;
#       border-radius: 16px;
#       background: linear-gradient(180deg, #0b0b10, #161623);
#       box-shadow: 0 0 20px rgba(255, 215, 0, 0.4); /* subtle gold glow */
#     }}
#     model-viewer {{
#       width: 100%;
#       height: 520px;
#       border-radius: 16px;
#       box-shadow: 0 8px 20px rgba(0, 0, 0, 0.7);
#       background: transparent;
#     }}
#     .status {{
#       color: #dfe3f0;
#       font: 14px/1.4 system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
#       opacity: 0.9;
#       margin-top: 8px;
#       user-select: none;
#       text-align: center;
#     }}
#     .pulse {{
#       animation: pulse 0.8s infinite;
#     }}
#     @keyframes pulse {{
#       0% {{ transform: translateY(0px); }}
#       50% {{ transform: translateY(-6px); }}
#       100% {{ transform: translateY(0px); }}
#     }}
#     audio {{
#       display: none; /* hide audio controls */
#     }}
#   </style>
# </head>
# <body>
#   <div class="container">
#     <model-viewer id="mv" src="{model_src}" shadow-intensity="0.7" {ar} {cc} exposure="1.0" camera-orbit="0deg 70deg 25m"></model-viewer>
#     <div id="status" class="status">Ready.</div>
#     <audio id="audio" src="data:audio/wav;base64,{audio_b64}"></audio>
#   </div>

#   <script>
#     const mv = document.getElementById('mv');
#     const status = document.getElementById('status');
#     const audio = document.getElementById('audio');

#     function startSpeaking() {{
#       status.textContent = 'Speaking…';
#       mv.classList.add('pulse');
#       audio.play().catch(() => {{
#         status.textContent = 'Click anywhere to play audio (autoplay blocked).';
#         document.body.addEventListener('click', () => audio.play(), {{ once: true }});
#       }});
#     }}

#     function stopSpeaking() {{
#       status.textContent = 'Ready.';
#       mv.classList.remove('pulse');
#     }}

#     audio.addEventListener('play', startSpeaking);
#     audio.addEventListener('ended', stopSpeaking);
#     audio.addEventListener('pause', stopSpeaking);

#     window.addEventListener('DOMContentLoaded', () => {{
#       setTimeout(() => audio.play().catch(() => {{}}), 150);
#     }});
#   </script>
# </body>
# </html>
# """




# def html_iframe_with_audio(page_url: str, audio_b64: str) -> str:
#     """Embed a remote viewer page (e.g., Meshy model page) alongside an audio player."""
#     return f"""
# <!DOCTYPE html>
# <html>
# <head>
#   <meta charset=\"utf-8\" />
#   <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
#   <style>
#     body {{ margin:0; background:#0b0b10; }}
#     .grid {{ display:grid; grid-template-rows:auto 48px; gap:8px; height:600px; }}
#     iframe {{ width:100%; height:100%; border:0; border-radius:16px; background:#0b0b10; }}
#     audio {{ width:100%; }}
#   </style>
# </head>
# <body>
#   <div class=\"grid\">
#     <iframe src=\"{page_url}\" allow=\"autoplay; xr; webvr; webxr; fullscreen\"></iframe>
#     <audio controls autoplay src=\"data:audio/wav;base64,{audio_b64}\"></audio>
#   </div>
# </body>
# </html>
# """

# # ----------------------------
# # Resolve model source preference order
# # ----------------------------
# resolved_src = None
# is_meshy_page = False


# # Try to load local Ganesha model
# fixed_model_path = "ganesha_model.glb"   # Put your .glb in the same folder
# try:
#     with open(fixed_model_path, "rb") as f:
#         data = f.read()
#     b64 = base64.b64encode(data).decode("utf-8")
#     resolved_src = f"data:model/gltf-binary;base64,{b64}"
# except FileNotFoundError:
#     st.warning(f"Local model '{fixed_model_path}' not found. Please upload or provide a URL.")

# audio_b64 = st.session_state.get("last_audio_b64", "")

# # ----------------------------
# # Layout: Center 3D Ganesha, chat on the right
# # ----------------------------
# model_col, chat_col = st.columns([6, 4])

# with model_col:
#     st.subheader("🕉️ 3D Lord Ganesha")
    
#     if resolved_src:
#         html = html_3d_with_audio(resolved_src, audio_b64, auto_rotate, camera_controls)
#         components.html(html, height=600, scrolling=False)
#     elif is_meshy_page:
#         html = html_iframe_with_audio(model_url, audio_b64)
#         components.html(html, height=600, scrolling=False)
#     else:
#         st.info(
#             "Upload a .glb/.gltf file in the sidebar, "
#             "paste a direct model URL, or a Meshy model page URL to embed."
#         )

# with chat_col:
#     st.subheader("Chat")
#     with st.form("chat_form", clear_on_submit=True):
#         user_text = st.text_input(
#             "Type your message:", placeholder="Ask for guidance, blessings, or anything you like…"
#         )
#         colA, colB = st.columns([1, 1])
#         with colA:
#             send_btn = st.form_submit_button("Send")
#         with colB:
#             speak_btn = st.form_submit_button("🎙️ Speak")

#     transcript = None
#     if speak_btn:
#       try:
#           r = sr.Recognizer()
#           with sr.Microphone() as source:
#               st.info("Listening…")
#               audio_data = r.listen(source, timeout=5)
              
#               # Save temporary wav file
#               with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
#                   tmp.write(audio_data.get_wav_data())
#                   user_audio_path = tmp.name

#               # Recognize speech text
#               transcript = r.recognize_google(audio_data)
#               st.success(f"You said: {transcript}")

#               # Analyze user voice
#               user_pitch, user_tempo = analyze_user_voice(user_audio_path)

#       except Exception as e:
#           st.error(f"Voice input failed: {e}")
#           user_pitch, user_tempo = 0, 120  # fallback


#     active_prompt = transcript if transcript else (user_text if send_btn and user_text.strip() else None)

#     if api_key and active_prompt:
#         with st.spinner("Ganesha is thinking…"):
#             reply = generate_reply(active_prompt)
#         st.session_state.history.append(("You", active_prompt))
#         st.session_state.history.append(("Ganesha", reply))

#         # TTS
#         with st.spinner("Generating voice…"):
#             selected_voice_id = voice_options.get(voice_name, "Myna-mini")
#             if not selected_voice_id:
#                 st.error(f"Voice '{voice_name}' not found. Please select a valid voice from the sidebar.")
#                 selected_voice_id = None
#                 # Generate TTS
#             tts_bytes_data = tts_bytes(reply, selected_voice_id, style_prompt)

#             # Save temporary TTS file
#             with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp_tts:
#                 tmp_tts.write(tts_bytes_data)
#                 tts_path = tmp_tts.name

#             # Adjust TTS to match user voice
#             adjusted_audio = adjust_tts_pitch_speed(tts_path, user_pitch, user_tempo)
#             # Cartoon filter: higher pitch (chipmunk-like)
#             cartoon_voice = adjusted_audio._spawn(adjusted_audio.raw_data, overrides={
#                 "frame_rate": int(adjusted_audio.frame_rate * 1.5)  # pitch up
#             }).set_frame_rate(adjusted_audio.frame_rate)
#             # cartoon_voice = cartoonify_librosa(tts_path, semitones=5)
#             # You can also do deep/monster effect by lowering pitch:
#             # cartoon_voice = adjusted_audio._spawn(adjusted_audio.raw_data, overrides={
#             #     "frame_rate": int(adjusted_audio.frame_rate * 0.7)
#             # }).set_frame_rate(adjusted_audio.frame_rate)

#             # Encode for Streamlit
#             with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as final_audio_file:
#                 cartoon_voice.export(final_audio_file.name, format="wav")
#                 with open(final_audio_file.name, "rb") as f:
#                     audio_b64 = base64.b64encode(f.read()).decode("utf-8")

#             st.session_state["last_audio_b64"] = audio_b64

#             st.session_state["last_audio_b64"] = audio_b64

#         # Show text reply
#         st.markdown(f"**🕉️ Ganesha:** {reply}")

#     st.markdown("---")
#     st.subheader("Conversation History")
#     if st.session_state.history:
#         for role, content in st.session_state.history:
#             if role == "You":
#                 st.markdown(f"**🧑 You:** {content}")
#             else:
#                 st.markdown(f"**🕉️ {role}:** {content}")
#     else:
#         st.caption("No messages yet.")

# # ----------------------------
# # Footer
# # ----------------------------
# st.markdown("""
# <div style='opacity:.7;font-size:12px'>
# Note: 3D rendering uses the <code>model-viewer</code> web component. Audio autoplay may be blocked on some browsers; if so, click the canvas once to start playback. Your API key stays in your browser session.
# </div>
# """, unsafe_allow_html=True)

import base64
import os
import streamlit as st
import streamlit.components.v1 as components
import speech_recognition as sr
from openai import OpenAI
from gtts import gTTS
import tempfile
import requests
import base64


def get_voices(api_key):
    url = "https://os.gan.ai/v1/voices"
    headers = {"ganos-api-key": api_key}
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    return response.json().get("data", [])

# ----------------------------
# Page setup
# ----------------------------
st.set_page_config(page_title="3D Ganesha Voice Chatbot", page_icon="🕉", layout="wide")
st.title("🕉 3D Lord Ganesha • Voice Chatbot")
st.caption("Type or speak to Ganesha. He replies with text and a deep, hoarse voice — and the 3D model animates while speaking.")

GAN_AI_API_KEY ="tGYdQHlYNZFe8qpCFNUeG4z-bz7XQJTsFdx53w5v"

try:
    voices = get_voices(GAN_AI_API_KEY)
    voice_options = {v['voice_name']: v['voice_id'] for v in voices}
except Exception as e:
    st.sidebar.error(f"Failed to fetch voices: {e}")
    voices = []
    voice_options = {}



# ----------------------------
# Sidebar controls
# ----------------------------
st.sidebar.header("Settings")
api_key = st.sidebar.text_input("OpenRouter API Key", type="password", help="Your key is only used locally in this app.")
model_text = st.sidebar.text_input("Text Model", value="gpt-4o-mini", help="Model used for text generation.")
model_tts = st.sidebar.text_input("TTS Model", value="gpt-4o-mini-tts", help="Model used for speech generation.")
if voice_options:
    voice_name = st.sidebar.selectbox("TTS Voice", options=list(voice_options.keys()), index=0)
else:
    voice_name = st.sidebar.text_input("TTS Voice", value="Myna-mini")

style_prompt = st.sidebar.text_input(
    "Voice Style",
    value="Speak like a gentle, wise cartoon deity, warm and playful, as if from an animated movie. Deep, hoarse, and loving tone.",
)

st.sidebar.markdown("---")
model_url = st.sidebar.text_input(
    "3D Model URL (.glb/.gltf)",
    value="",
    help=(
        "Paste a direct URL to a Lord Ganesha GLB/GLTF model. "
        "You can also embed any other GLB if you don't have one yet."
    ),
)
auto_rotate = st.sidebar.checkbox("Auto-rotate model", True)
camera_controls = st.sidebar.checkbox("Camera controls", True)

st.sidebar.markdown("---")
st.sidebar.write("*Tip:* Keep this window focused for audio to autoplay.")

# Guard for API key
if not api_key:
    st.info("Enter your OpenRouter API key in the sidebar to start.")

# ----------------------------
# OpenRouter / OpenAI client
# ----------------------------
client = None
if api_key:
    client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=api_key)

# ----------------------------
# Chat state
# ----------------------------
if "history" not in st.session_state:
    st.session_state.history = []  # list of (role, content)

# ----------------------------
# Helpers
# ----------------------------
def generate_reply(prompt: str) -> str:
    """LLM text generation via OpenRouter"""
    assert client is not None
    resp = client.chat.completions.create(
        model=model_text,
        messages=[
            {
                "role": "system",
                "content": (
                    "You are Lord Ganesha, a wise, gentle, and benevolent deity."
                    "Listen carefully to the user words, understand their intentions, and respond with warmth, guidance, and insight inspired by"
                    "Ganesha philosophies, stories, and cultural symbolism."
                    "Speak in a deep, hoarse, gravelly tone, warm and comforting,"
                    "like a gentle deity guiding a devotee, giving practical, concise, and divine advice that blesses and enlightens the seeker."
                ),
            },
            {"role": "user", "content": prompt},
        ],
    )
    return resp.choices[0].message.content


def tts_bytes(text: str, voice_id: str, style_prompt: str = "") -> bytes:
    url = "https://os.gan.ai/v1/tts"
    headers = {
        "Content-Type": "application/json",
        "ganos-api-key": GAN_AI_API_KEY
    }
    body = {
        "voice_id": voice_id,
        "text": text,
        "style": style_prompt  # pass the style here
    }
    response = requests.post(url, headers=headers, json=body)
    
    print(f"Status code: {response.status_code}")
    print(f"Response body: {response.text}")
    
    response.raise_for_status()
    return response.content




def html_3d_with_audio(model_src: str, audio_b64: str, auto_rotate: bool, camera_controls: bool) -> str:
    ar = "auto-rotate" if auto_rotate else ""
    cc = "camera-controls" if camera_controls else ""

    return f"""
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <script type="module" src="https://unpkg.com/@google/model-viewer/dist/model-viewer.min.js"></script>
  <style>
    body {{
      margin: 0;
      background: #0b0b10;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh; /* full viewport height */
      overflow: hidden;
    }}
    .container {{
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      width: 100%;
      max-width: 600px;
      height: 600px;
      padding: 20px;
      box-sizing: border-box;
      border-radius: 16px;
      background: linear-gradient(180deg, #0b0b10, #161623);
      box-shadow: 0 0 20px rgba(255, 215, 0, 0.4); /* subtle gold glow */
    }}
    model-viewer {{
      width: 100%;
      height: 520px;
      border-radius: 16px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.7);
      background: transparent;
    }}
    .status {{
      color: #dfe3f0;
      font: 14px/1.4 system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
      opacity: 0.9;
      margin-top: 8px;
      user-select: none;
      text-align: center;
    }}
    .pulse {{
      animation: pulse 0.8s infinite;
    }}
    @keyframes pulse {{
      0% {{ transform: translateY(0px); }}
      50% {{ transform: translateY(-6px); }}
      100% {{ transform: translateY(0px); }}
    }}
    audio {{
      display: none; /* hide audio controls */
    }}
  </style>
</head>
<body>
  <div class="container">
    <model-viewer id="mv" src="{model_src}" shadow-intensity="0.7" {ar} {cc} exposure="1.0" camera-orbit="0deg 70deg 25m"></model-viewer>
    <div id="status" class="status">Ready.</div>
    <audio id="audio" src="data:audio/wav;base64,{audio_b64}"></audio>
  </div>

  <script>
    const mv = document.getElementById('mv');
    const status = document.getElementById('status');
    const audio = document.getElementById('audio');

    function startSpeaking() {{
      status.textContent = 'Speaking…';
      mv.classList.add('pulse');
      audio.play().catch(() => {{
        status.textContent = 'Click anywhere to play audio (autoplay blocked).';
        document.body.addEventListener('click', () => audio.play(), {{ once: true }});
      }});
    }}

    function stopSpeaking() {{
      status.textContent = 'Ready.';
      mv.classList.remove('pulse');
    }}

    audio.addEventListener('play', startSpeaking);
    audio.addEventListener('ended', stopSpeaking);
    audio.addEventListener('pause', stopSpeaking);

    window.addEventListener('DOMContentLoaded', () => {{
      setTimeout(() => audio.play().catch(() => {{}}), 150);
    }});
  </script>
</body>
</html>
"""




def html_iframe_with_audio(page_url: str, audio_b64: str) -> str:
    """Embed a remote viewer page (e.g., Meshy model page) alongside an audio player."""
    return f"""
<!DOCTYPE html>
<html>
<head>
  <meta charset=\"utf-8\" />
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
  <style>
    body {{ margin:0; background:#0b0b10; }}
    .grid {{ display:grid; grid-template-rows:auto 48px; gap:8px; height:600px; }}
    iframe {{ width:100%; height:100%; border:0; border-radius:16px; background:#0b0b10; }}
    audio {{ width:100%; }}
  </style>
</head>
<body>
  <div class=\"grid\">
    <iframe src=\"{page_url}\" allow=\"autoplay; xr; webvr; webxr; fullscreen\"></iframe>
    <audio controls autoplay src=\"data:audio/wav;base64,{audio_b64}\"></audio>
  </div>
</body>
</html>
"""

# ----------------------------
# Resolve model source preference order
# ----------------------------
resolved_src = None
is_meshy_page = False

# Try to load local Ganesha model
fixed_model_path = "ganesha_model.glb"   # Put your .glb in the same folder
try:
    with open(fixed_model_path, "rb") as f:
        data = f.read()
    b64 = base64.b64encode(data).decode("utf-8")
    resolved_src = f"data:model/gltf-binary;base64,{b64}"
except FileNotFoundError:
    st.warning(f"Local model '{fixed_model_path}' not found. Please upload or provide a URL.")

audio_b64 = st.session_state.get("last_audio_b64", "")

# ----------------------------
# Layout: Center 3D Ganesha, chat on the right
# ----------------------------
model_col, chat_col = st.columns([6, 4])

with model_col:
    st.subheader("🕉 3D Lord Ganesha")
    
    if resolved_src:
        html = html_3d_with_audio(resolved_src, audio_b64, auto_rotate, camera_controls)
        components.html(html, height=600, scrolling=False)
    elif is_meshy_page:
        html = html_iframe_with_audio(model_url, audio_b64)
        components.html(html, height=600, scrolling=False)
    else:
        st.info(
            "Upload a .glb/.gltf file in the sidebar, "
            "paste a direct model URL, or a Meshy model page URL to embed."
        )

with chat_col:
    st.subheader("Chat")
    with st.form("chat_form", clear_on_submit=True):
        user_text = st.text_input(
            "Type your message:", placeholder="Ask for guidance, blessings, or anything you like…"
        )
        colA, colB = st.columns([1, 1])
        with colA:
            send_btn = st.form_submit_button("Send")
        with colB:
            speak_btn = st.form_submit_button("🎙 Speak")

    transcript = None
    if speak_btn:
        try:
            r = sr.Recognizer()
            with sr.Microphone() as source:
                st.info("Listening…")
                audio = r.listen(source, timeout=5)
                transcript = r.recognize_google(audio)
                st.success(f"You said: {transcript}")
        except Exception as e:
            st.error(f"Voice input failed: {e}")

    active_prompt = transcript if transcript else (user_text if send_btn and user_text.strip() else None)

    if api_key and active_prompt:
        with st.spinner("Ganesha is thinking…"):
            reply = generate_reply(active_prompt)
        st.session_state.history.append(("You", active_prompt))
        st.session_state.history.append(("Ganesha", reply))

        # TTS
        with st.spinner("Generating voice…"):
            selected_voice_id = voice_options.get(voice_name, "Myna-mini")
            if not selected_voice_id:
              st.error(f"Voice '{voice_name}' not found. Please select a valid voice from the sidebar.")
              selected_voice_id = None
            audio_bytes = tts_bytes(reply, selected_voice_id,style_prompt)
            audio_b64 = base64.b64encode(audio_bytes).decode("utf-8")
            st.session_state["last_audio_b64"] = audio_b64

        # Show text reply
        st.markdown(f"🕉 Ganesha:** {reply}")

    st.markdown("---")
    st.subheader("Conversation History")
    if st.session_state.history:
        for role, content in st.session_state.history:
            if role == "You":
                st.markdown(f"🧑 You:** {content}")
            else:
                st.markdown(f"🕉 {role}:** {content}")
    else:
        st.caption("No messages yet.")

# ----------------------------
# Footer
# ----------------------------
st.markdown("""
<div style='opacity:.7;font-size:12px'>
Note: 3D rendering uses the <code>model-viewer</code> web component. Audio autoplay may be blocked on some browsers; if so, click the canvas once to start playback. Your API key stays in your browser session.
</div>
""", unsafe_allow_html=True)
