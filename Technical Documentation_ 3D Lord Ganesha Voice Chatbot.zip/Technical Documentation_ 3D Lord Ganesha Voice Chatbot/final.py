# import base64
# import os
# import streamlit as st
# import streamlit.components.v1 as components
# import speech_recognition as sr
# from openai import OpenAI
# from gtts import gTTS
# import tempfile
# import requests


# ELEVENLABS_API_KEY = "sk_b330fbded1df2cca25d387ba5d4c89bdb1384dac4cc43983"

# def get_voices(api_key):
#     url = "https://os.gan.ai/v1/voices"
#     headers = {"ganos-api-key": api_key}
#     response = requests.get(url, headers=headers)
#     response.raise_for_status()
#     return response.json().get("data", [])

# # ----------------------------
# # Page setup
# # ----------------------------
# st.set_page_config(page_title="3D Ganesha Voice Chatbot", page_icon="🕉️", layout="wide")
# st.title("🕉️ 3D Lord Ganesha • Voice Chatbot")
# st.caption("Type or speak to Ganesha. He replies with text and a deep, hoarse voice — and the 3D model animates while speaking.")

# GAN_AI_API_KEY ="tGYdQHlYNZFe8qpCFNUeG4z-bz7XQJTsFdx53w5v"

# try:
#     voices = get_voices(GAN_AI_API_KEY)
#     voice_options = {v['voice_name']: v['voice_id'] for v in voices}
# except Exception as e:
#     st.sidebar.error(f"Failed to fetch voices: {e}")
#     voices = []
#     voice_options = {}



# # ----------------------------
# # Sidebar controls
# # ----------------------------
# st.sidebar.header("Settings")
# api_key = st.sidebar.text_input("OpenRouter API Key", type="password", help="Your key is only used locally in this app.")
# model_text = st.sidebar.text_input("Text Model", value="gpt-oss-20b", help="Model used for text generation.")
# model_tts = st.sidebar.text_input("TTS Model", value="gpt-4o-mini-tts", help="Model used for speech generation.")
# if voice_options:
#     voice_name = st.sidebar.selectbox("TTS Voice", options=list(voice_options.keys()), index=0)
# else:
#     voice_name = st.sidebar.text_input("TTS Voice", value="Myna-mini")

# style_prompt = st.sidebar.text_input(
#     "Voice Style",
#     value="Speak like a gentle, wise cartoon deity, warm and playful, as if from an animated movie. Deep, hoarse, and loving tone.",
# )

# st.sidebar.markdown("---")
# model_url = st.sidebar.text_input(
#     "3D Model URL (.glb/.gltf)",
#     value="",
#     help=(
#         "Paste a direct URL to a Lord Ganesha GLB/GLTF model. "
#         "You can also embed any other GLB if you don't have one yet."
#     ),
# )
# auto_rotate = st.sidebar.checkbox("Auto-rotate model", True)
# camera_controls = st.sidebar.checkbox("Camera controls", True)

# st.sidebar.markdown("---")
# st.sidebar.write("**Tip:** Keep this window focused for audio to autoplay.")

# # Guard for API key
# if not api_key:
#     st.info("Enter your OpenRouter API key in the sidebar to start.")

# # ----------------------------
# # OpenRouter / OpenAI client
# # ----------------------------
# client = None
# if api_key:
#     client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=api_key)

# # ----------------------------
# # Chat state
# # ----------------------------
# if "history" not in st.session_state:
#     st.session_state.history = []  # list of (role, content)

# # ----------------------------
# # Helpers
# # ----------------------------
# def generate_reply(prompt: str) -> str:
#     """LLM text generation via OpenRouter"""
#     assert client is not None
#     resp = client.chat.completions.create(
#         model=model_text,
#         messages=[
#             {
#                 "role": "system",
#                 "content": (
#                     "You are Lord Ganesha, a wise, gentle, and benevolent deity."
#                     "Listen carefully to the user words, understand their intentions, and respond with warmth, guidance, and insight inspired by"
#                     "Ganesha philosophies, stories, and cultural symbolism."
#                     "Speak in a deep, hoarse, gravelly tone, warm and comforting,"
#                     "like a gentle deity guiding a devotee, giving practical, concise, and divine advice that blesses and enlightens the seeker."
#                 ),
#             },
#             {"role": "user", "content": prompt},
#         ],
#     )
#     return resp.choices[0].message.content


# # def tts_bytes(text: str, voice_id: str, style_prompt: str = "") -> bytes:
# #     url = "https://os.gan.ai/v1/tts"
# #     headers = {
# #         "Content-Type": "application/json",
# #         "ganos-api-key": GAN_AI_API_KEY
# #     }
# #     body = {
# #         "voice_id": voice_id,
# #         "text": text,
# #         "style": style_prompt  # pass the style here
# #     }
# #     response = requests.post(url, headers=headers, json=body)
    
# #     print(f"Status code: {response.status_code}")
# #     print(f"Response body: {response.text}")
    
# #     response.raise_for_status()
# #     return response.content

# def get_elevenlabs_voices():
#     url = "https://api.elevenlabs.io/v1/voices"
#     headers = {"xi-api-key": ELEVENLABS_API_KEY}
#     response = requests.get(url, headers=headers)
#     print("Status code:", response.status_code)
#     print("Response text:", response.text)  # check if it returns JSON
#     response.raise_for_status()  # will raise if not 200
#     voices = response.json().get("voices", [])
#     return voices


# voices = get_elevenlabs_voices()

# def tts_bytes_elevenlabs(text: str, voice: str = "alloy") -> bytes:
#     """
#     Generate speech using ElevenLabs API.
#     voice: can be 'alloy', 'amber', or any custom voice ID.
#     """
#     url = f"https://elevenlabs.io/app/voice-library?voiceId=8sWH93U9U0KfEJZdaI8Z"
#     headers = {
#         "xi-api-key": ELEVENLABS_API_KEY,
#         "Content-Type": "application/json"
#     }
#     data = {
#         "text": text,
#         "voice_settings": {
#             "stability": 0.7,  # 0-1
#             "similarity_boost": 0.75  # 0-1
#         }
#     }
#     response = requests.post(url, json=data, headers=headers)
#     response.raise_for_status()
#     return response.content


# def html_3d_with_audio(model_src: str, audio_b64: str, auto_rotate: bool, camera_controls: bool) -> str:
    
#     ar = "auto-rotate" if auto_rotate else ""
#     cc = "camera-controls" if camera_controls else ""

#     return f"""
# <!DOCTYPE html>
# <html>
# <head>
#   <meta charset="utf-8" />
#   <meta name="viewport" content="width=device-width, initial-scale=1" />
#   <script type="module" src="https://unpkg.com/@google/model-viewer/dist/model-viewer.min.js"></script>
#   <style>
#     body {{
#       margin: 0;
#       background: #0b0b10;
#       display: flex;
#       justify-content: center;
#       align-items: center;
#       height: 100vh;
#       overflow: hidden;
#     }}
#     .container {{
#       display: flex;
#       flex-direction: column;
#       align-items: center;
#       justify-content: center;
#       width: 100%;
#       max-width: 600px;
#       height: 600px;
#       padding: 20px;
#       box-sizing: border-box;
#       border-radius: 16px;
#       background: linear-gradient(180deg, #0b0b10, #161623);
#       box-shadow: 0 0 20px rgba(255, 215, 0, 0.4);
#     }}
#     model-viewer {{
#       width: 100%;
#       height: 520px;
#       border-radius: 16px;
#       box-shadow: 0 8px 20px rgba(0, 0, 0, 0.7);
#       background: transparent;
#     }}
#     .controls {{
#       margin-top: 8px;
#     }}
#     button {{
#       background:#ffd700;
#       border:none;
#       padding:6px 12px;
#       border-radius:8px;
#       font-size:14px;
#       cursor:pointer;
#       margin:0 4px;
#     }}
#     .status {{
#       color: #dfe3f0;
#       font: 14px/1.4 system-ui, sans-serif;
#       margin-top: 6px;
#     }}
#     .pulse {{ animation: pulse 0.8s infinite; }}
#     @keyframes pulse {{
#       0% {{ transform: translateY(0px); }}
#       50% {{ transform: translateY(-6px); }}
#       100% {{ transform: translateY(0px); }}
#     }}
#     audio {{ display:none; }}
#   </style>
# </head>
# <body>
#   <div class="container">
#     <model-viewer id="mv"
#       src="{model_src}"
#       shadow-intensity="0.7"
#       {cc}
#       exposure="1.0"
#       camera-orbit="0deg 70deg 2m"
#       min-camera-orbit="-45deg 70deg 2m"
#       max-camera-orbit="45deg 70deg 2m">
#     </model-viewer>
#     <div class="controls">
#       <button id="pauseBtn">⏸ Pause</button>
#       <button id="playBtn" style="display:none;">▶ Play</button>
#     </div>
#     <div id="status" class="status">Ready.</div>
#     <audio id="audio" src="data:audio/wav;base64,{audio_b64}"></audio>
#   </div>

#   <script>
#     const mv = document.getElementById('mv');
#     const status = document.getElementById('status');
#     const audio = document.getElementById('audio');
#     const pauseBtn = document.getElementById('pauseBtn');
#     const playBtn = document.getElementById('playBtn');

#     function startSpeaking() {{
#       status.textContent = 'Speaking…';
#       mv.classList.add('pulse');
#     }}

#     function stopSpeaking() {{
#       status.textContent = 'Ready.';
#       mv.classList.remove('pulse');
#     }}

#     audio.addEventListener('play', startSpeaking);
#     audio.addEventListener('ended', stopSpeaking);
#     audio.addEventListener('pause', stopSpeaking);

#     pauseBtn.addEventListener('click', () => {{
#       audio.pause();
#       pauseBtn.style.display = 'none';
#       playBtn.style.display = 'inline-block';
#     }});

#     playBtn.addEventListener('click', () => {{
#       audio.play();
#       playBtn.style.display = 'none';
#       pauseBtn.style.display = 'inline-block';
#     }});

#     // Always restart audio when page loads
#     window.addEventListener('DOMContentLoaded', () => {{
#       audio.currentTime = 0;
#       audio.play().catch(() => {{}});
#     }});
#   </script>
# </body>
# </html>
# """





# def html_iframe_with_audio(page_url: str, audio_b64: str) -> str:
#     """Embed a remote viewer page (e.g., Meshy model page) alongside an audio player."""
#     return f"""
# <!DOCTYPE html>
# <html>
# <head>
#   <meta charset=\"utf-8\" />
#   <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
#   <style>
#     body {{ margin:0; background:#0b0b10; }}
#     .grid {{ display:grid; grid-template-rows:auto 48px; gap:8px; height:600px; }}
#     iframe {{ width:100%; height:100%; border:0; border-radius:16px; background:#0b0b10; }}
#     audio {{ width:100%; }}
#   </style>
# </head>
# <body>
#   <div class=\"grid\">
#     <iframe src=\"{page_url}\" allow=\"autoplay; xr; webvr; webxr; fullscreen\"></iframe>
#     <audio controls autoplay src=\"data:audio/wav;base64,{audio_b64}\"></audio>
#   </div>
# </body>
# </html>
# """

# # ----------------------------
# # Resolve model source preference order
# # ----------------------------
# resolved_src = None
# is_meshy_page = False

# # Try to load local Ganesha model
# fixed_model_path = "ganesha_model.glb"   # Put your .glb in the same folder
# try:
#     with open(fixed_model_path, "rb") as f:
#         data = f.read()
#     b64 = base64.b64encode(data).decode("utf-8")
#     resolved_src = f"data:model/gltf-binary;base64,{b64}"
# except FileNotFoundError:
#     st.warning(f"Local model '{fixed_model_path}' not found. Please upload or provide a URL.")

# audio_b64 = st.session_state.get("last_audio_b64", "")

# # ----------------------------
# # Layout: Center 3D Ganesha, chat on the right
# # ----------------------------
# model_col, chat_col = st.columns([6, 4])

# with model_col:
#     st.subheader("🕉️ 3D Lord Ganesha")
    
#     if resolved_src:
#         html = html_3d_with_audio(resolved_src, audio_b64, auto_rotate, camera_controls)
#         components.html(html, height=600, scrolling=False)
#     elif is_meshy_page:
#         html = html_iframe_with_audio(model_url, audio_b64)
#         components.html(html, height=600, scrolling=False)
#     else:
#         st.info(
#             "Upload a .glb/.gltf file in the sidebar, "
#             "paste a direct model URL, or a Meshy model page URL to embed."
#         )

# with chat_col:
#     st.subheader("Chat")
#     with st.form("chat_form", clear_on_submit=True):
#         user_text = st.text_input(
#             "Type your message:", placeholder="Ask for guidance, blessings, or anything you like…"
#         )
#         colA, colB = st.columns([1, 1])
#         with colA:
#             send_btn = st.form_submit_button("Send")
#         with colB:
#             speak_btn = st.form_submit_button("🎙️ Speak")

#     transcript = None
#     if speak_btn:
#         try:
#             r = sr.Recognizer()
#             with sr.Microphone() as source:
#                 st.info("Listening…")
#                 audio = r.listen(source, timeout=5)
#                 transcript = r.recognize_google(audio)
#                 st.success(f"You said: {transcript}")
#         except Exception as e:
#             st.error(f"Voice input failed: {e}")

#     active_prompt = transcript if transcript else (user_text if send_btn and user_text.strip() else None)

#     if api_key and active_prompt:
#         with st.spinner("Ganesha is thinking…"):
#             reply = generate_reply(active_prompt)
#         st.session_state.history.append(("You", active_prompt))
#         st.session_state.history.append(("Ganesha", reply))

#         # TTS
#         with st.spinner("Generating voice…"):
#             selected_voice_id = voice_options.get(voice_name, "Myna-mini")
#             if not selected_voice_id:
#               st.error(f"Voice '{voice_name}' not found. Please select a valid voice from the sidebar.")
#               selected_voice_id = None
#             audio_bytes = tts_bytes_elevenlabs(reply, voice="21m00Tcm4TlvDq8ikWAM")  # or a custom voice ID

#             audio_b64 = base64.b64encode(audio_bytes).decode("utf-8")
#             st.session_state["last_audio_b64"] = audio_b64

#         # Show text reply
#         st.markdown(f"**🕉️ Ganesha:** {reply}")

#     st.markdown("---")
#     st.subheader("Conversation History")
#     if st.session_state.history:
#         for role, content in st.session_state.history:
#             if role == "You":
#                 st.markdown(f"**🧑 You:** {content}")
#             else:
#                 st.markdown(f"**🕉️ {role}:** {content}")
#     else:
#         st.caption("No messages yet.")

# # ----------------------------
# # Footer
# # ----------------------------
# st.markdown("""
# <div style='opacity:.7;font-size:12px'>
# Note: 3D rendering uses the <code>model-viewer</code> web component. Audio autoplay may be blocked on some browsers; if so, click the canvas once to start playback. Your API key stays in your browser session.
# </div>
# """, unsafe_allow_html=True)

import base64
import os
import streamlit as st
import streamlit.components.v1 as components
import speech_recognition as sr
from openai import OpenAI
from gtts import gTTS
import tempfile
import requests


ELEVENLABS_API_KEY = "sk_13bda6633e56b278c0b9b5ec61cad34c4f0ae57943a5eec1"

def get_voices(api_key):
    url = "https://os.gan.ai/v1/voices"
    headers = {"ganos-api-key": api_key}
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    return response.json().get("data", [])

# ----------------------------
# Page setup
# ----------------------------
st.set_page_config(page_title="3D Ganesha Voice Chatbot", page_icon="🕉", layout="wide")
st.title("🕉 3D Lord Ganesha • Voice Chatbot")
st.caption("Type or speak to Ganesha. He replies with text and a deep, hoarse voice — and the 3D model animates while speaking.")

GAN_AI_API_KEY ="tGYdQHlYNZFe8qpCFNUeG4z-bz7XQJTsFdx53w5v"

try:
    voices = get_voices(GAN_AI_API_KEY)
    voice_options = {v['voice_name']: v['voice_id'] for v in voices}
except Exception as e:
    st.sidebar.error(f"Failed to fetch voices: {e}")
    voices = []
    voice_options = {}



# ----------------------------
# Sidebar controls
# ----------------------------
st.sidebar.header("Settings")
api_key = st.sidebar.text_input("OpenRouter API Key", type="password", help="Your key is only used locally in this app.")
model_text = st.sidebar.text_input("Text Model", value="gpt-oss-20b", help="Model used for text generation.")
model_tts = st.sidebar.text_input("TTS Model", value="gpt-4o-mini-tts", help="Model used for speech generation.")
if voice_options:
    voice_name = st.sidebar.selectbox("TTS Voice", options=list(voice_options.keys()), index=0)
else:
    voice_name = st.sidebar.text_input("TTS Voice", value="Myna-mini")

style_prompt = st.sidebar.text_input(
    "Voice Style",
    value="Speak like a gentle, wise cartoon deity, warm and playful, as if from an animated movie. Deep, hoarse, and loving tone.",
)

st.sidebar.markdown("---")
model_url = st.sidebar.text_input(
    "3D Model URL (.glb/.gltf)",
    value="",
    help=(
        "Paste a direct URL to a Lord Ganesha GLB/GLTF model. "
        "You can also embed any other GLB if you don't have one yet."
    ),
)
auto_rotate = st.sidebar.checkbox("Auto-rotate model", True)
camera_controls = st.sidebar.checkbox("Camera controls", True)

st.sidebar.markdown("---")
st.sidebar.write("*Tip:* Keep this window focused for audio to autoplay.")

# Guard for API key
if not api_key:
    st.info("Enter your OpenRouter API key in the sidebar to start.")

# ----------------------------
# OpenRouter / OpenAI client
# ----------------------------
client = None
if api_key:
    client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=api_key)

# ----------------------------
# Chat state
# ----------------------------
if "history" not in st.session_state:
    st.session_state.history = []  # list of (role, content)

# ----------------------------
# Helpers
# ----------------------------
def generate_reply(prompt: str) -> str:
    """LLM text generation via OpenRouter"""
    assert client is not None
    resp = client.chat.completions.create(
        model=model_text,
        messages=[
            {
                "role": "system",
                "content": (
                    "You are Lord Ganesha, a wise, gentle, and benevolent deity."
                    "Listen carefully to the user words, understand their intentions, and respond with warmth, guidance, and insight inspired by"
                    "Ganesha philosophies, stories, and cultural symbolism."
                    "Speak in a deep, hoarse, gravelly tone, warm and comforting,"
                    "like a gentle deity guiding a devotee, giving practical, concise, and divine advice that blesses and enlightens the seeker."
                ),
            },
            {"role": "user", "content": prompt},
        ],
    )
    return resp.choices[0].message.content


# def tts_bytes(text: str, voice_id: str, style_prompt: str = "") -> bytes:
#     url = "https://os.gan.ai/v1/tts"
#     headers = {
#         "Content-Type": "application/json",
#         "ganos-api-key": GAN_AI_API_KEY
#     }
#     body = {
#         "voice_id": voice_id,
#         "text": text,
#         "style": style_prompt  # pass the style here
#     }
#     response = requests.post(url, headers=headers, json=body)
    
#     print(f"Status code: {response.status_code}")
#     print(f"Response body: {response.text}")
    
#     response.raise_for_status()
#     return response.content

def get_elevenlabs_voices():
    url = "https://api.elevenlabs.io/v1/voices"
    headers = {"xi-api-key": ELEVENLABS_API_KEY}
    response = requests.get(url, headers=headers)
    print("Status code:", response.status_code)
    print("Response text:", response.text)  # check if it returns JSON
    response.raise_for_status()  # will raise if not 200
    voices = response.json().get("voices", [])
    return voices


voices = get_elevenlabs_voices()

def tts_bytes_elevenlabs(text: str, voice: str = "alloy") -> bytes:
    """
    Generate speech using ElevenLabs API.
    voice: can be 'alloy', 'amber', or any custom voice ID.
    """
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice}"
    headers = {
        "xi-api-key": ELEVENLABS_API_KEY,
        "Content-Type": "application/json"
    }
    data = {
        "text": text,
        "voice_settings": {
            "stability": 0.7,  # 0-1
            "similarity_boost": 0.75  # 0-1
        }
    }
    response = requests.post(url, json=data, headers=headers)
    response.raise_for_status()
    return response.content


def html_3d_with_audio(model_src: str, audio_b64: str, auto_rotate: bool, camera_controls: bool) -> str:
    
    ar = "auto-rotate" if auto_rotate else ""
    cc = "camera-controls" if camera_controls else ""

    return f"""
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <script type="module" src="https://unpkg.com/@google/model-viewer/dist/model-viewer.min.js"></script>
  <style>
    body {{
      margin: 0;
      background: #0b0b10;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      overflow: hidden;
    }}
    .container {{
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      width: 100%;
      max-width: 600px;
      height: 600px;
      padding: 20px;
      box-sizing: border-box;
      border-radius: 16px;
      background: linear-gradient(180deg, #0b0b10, #161623);
      box-shadow: 0 0 20px rgba(255, 215, 0, 0.4);
    }}
    model-viewer {{
      width: 100%;
      height: 520px;
      border-radius: 16px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.7);
      background: transparent;
    }}
    .controls {{
      margin-top: 8px;
    }}
    button {{
      background:#ffd700;
      border:none;
      padding:6px 12px;
      border-radius:8px;
      font-size:14px;
      cursor:pointer;
      margin:0 4px;
    }}
    .status {{
      color: #dfe3f0;
      font: 14px/1.4 system-ui, sans-serif;
      margin-top: 6px;
    }}
    .pulse {{ animation: pulse 0.8s infinite; }}
    @keyframes pulse {{
      0% {{ transform: translateY(0px); }}
      50% {{ transform: translateY(-6px); }}
      100% {{ transform: translateY(0px); }}
    }}
    audio {{ display:none; }}
  </style>
</head>
<body>
  <div class="container">
    <model-viewer id="mv"
      src="{model_src}"
      shadow-intensity="0.7"
      {cc}
      exposure="1.0"
      camera-orbit="0deg 70deg 2m"
      min-camera-orbit="-45deg 70deg 2m"
      max-camera-orbit="45deg 70deg 2m">
    </model-viewer>
    <div class="controls">
      <button id="pauseBtn">⏸ Pause</button>
      <button id="playBtn" style="display:none;">▶ Play</button>
    </div>
    <div id="status" class="status">Ready.</div>
    <audio id="audio" src="data:audio/wav;base64,{audio_b64}"></audio>
  </div>

  <script>
    const mv = document.getElementById('mv');
    const status = document.getElementById('status');
    const audio = document.getElementById('audio');
    const pauseBtn = document.getElementById('pauseBtn');
    const playBtn = document.getElementById('playBtn');

    function startSpeaking() {{
      status.textContent = 'Speaking…';
      mv.classList.add('pulse');
    }}

    function stopSpeaking() {{
      status.textContent = 'Ready.';
      mv.classList.remove('pulse');
    }}

    audio.addEventListener('play', startSpeaking);
    audio.addEventListener('ended', stopSpeaking);
    audio.addEventListener('pause', stopSpeaking);

    pauseBtn.addEventListener('click', () => {{
      audio.pause();
      pauseBtn.style.display = 'none';
      playBtn.style.display = 'inline-block';
    }});

    playBtn.addEventListener('click', () => {{
      audio.play();
      playBtn.style.display = 'none';
      pauseBtn.style.display = 'inline-block';
    }});

    // Always restart audio when page loads
    window.addEventListener('DOMContentLoaded', () => {{
      audio.currentTime = 0;
      audio.play().catch(() => {{}});
    }});
  </script>
</body>
</html>
"""





def html_iframe_with_audio(page_url: str, audio_b64: str) -> str:
    """Embed a remote viewer page (e.g., Meshy model page) alongside an audio player."""
    return f"""
<!DOCTYPE html>
<html>
<head>
  <meta charset=\"utf-8\" />
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
  <style>
    body {{ margin:0; background:#0b0b10; }}
    .grid {{ display:grid; grid-template-rows:auto 48px; gap:8px; height:600px; }}
    iframe {{ width:100%; height:100%; border:0; border-radius:16px; background:#0b0b10; }}
    audio {{ width:100%; }}
  </style>
</head>
<body>
  <div class=\"grid\">
    <iframe src=\"{page_url}\" allow=\"autoplay; xr; webvr; webxr; fullscreen\"></iframe>
    <audio controls autoplay src=\"data:audio/wav;base64,{audio_b64}\"></audio>
  </div>
</body>
</html>
"""

# ----------------------------
# Resolve model source preference order
# ----------------------------
resolved_src = None
is_meshy_page = False

# Try to load local Ganesha model
fixed_model_path = "ganesha_model.glb"   # Put your .glb in the same folder
try:
    with open(fixed_model_path, "rb") as f:
        data = f.read()
    b64 = base64.b64encode(data).decode("utf-8")
    resolved_src = f"data:model/gltf-binary;base64,{b64}"
except FileNotFoundError:
    st.warning(f"Local model '{fixed_model_path}' not found. Please upload or provide a URL.")

audio_b64 = st.session_state.get("last_audio_b64", "")

# ----------------------------
# Layout: Center 3D Ganesha, chat on the right
# ----------------------------
model_col, chat_col = st.columns([6, 4])

with model_col:
    st.subheader("🕉 3D Lord Ganesha")
    
    if resolved_src:
        html = html_3d_with_audio(resolved_src, audio_b64, auto_rotate, camera_controls)
        components.html(html, height=600, scrolling=False)
    elif is_meshy_page:
        html = html_iframe_with_audio(model_url, audio_b64)
        components.html(html, height=600, scrolling=False)
    else:
        st.info(
            "Upload a .glb/.gltf file in the sidebar, "
            "paste a direct model URL, or a Meshy model page URL to embed."
        )

with chat_col:
    st.subheader("Chat")
    with st.form("chat_form", clear_on_submit=True):
        user_text = st.text_input(
            "Type your message:", placeholder="Ask for guidance, blessings, or anything you like…"
        )
        colA, colB = st.columns([1, 1])
        with colA:
            send_btn = st.form_submit_button("Send")
        with colB:
            speak_btn = st.form_submit_button("🎙 Speak")

    transcript = None
    if speak_btn:
        try:
            r = sr.Recognizer()
            with sr.Microphone() as source:
                st.info("Listening…")
                audio = r.listen(source, timeout=5)
                transcript = r.recognize_google(audio)
                st.success(f"You said: {transcript}")
        except Exception as e:
            st.error(f"Voice input failed: {e}")

    active_prompt = transcript if transcript else (user_text if send_btn and user_text.strip() else None)

    if api_key and active_prompt:
        with st.spinner("Ganesha is thinking…"):
            reply = generate_reply(active_prompt)
        st.session_state.history.append(("You", active_prompt))
        st.session_state.history.append(("Ganesha", reply))

        # TTS
        with st.spinner("Generating voice…"):
            selected_voice_id = voice_options.get(voice_name, "Myna-mini")
            if not selected_voice_id:
              st.error(f"Voice '{voice_name}' not found. Please select a valid voice from the sidebar.")
              selected_voice_id = None
            audio_bytes = tts_bytes_elevenlabs(reply, voice="F4AXgTwG8nWPB9dcXaTh")  # or a custom voice ID

            audio_b64 = base64.b64encode(audio_bytes).decode("utf-8")
            st.session_state["last_audio_b64"] = audio_b64

        # Show text reply
        st.markdown(f"🕉 Ganesha:** {reply}")

    st.markdown("---")
    st.subheader("Conversation History")
    if st.session_state.history:
        for role, content in st.session_state.history:
            if role == "You":
                st.markdown(f"🧑 You:** {content}")
            else:
                st.markdown(f"🕉 {role}:** {content}")
    else:
        st.caption("No messages yet.")

# ----------------------------
# Footer
# ----------------------------
st.markdown("""
<div style='opacity:.7;font-size:12px'>
Note: 3D rendering uses the <code>model-viewer</code> web component. Audio autoplay may be blocked on some browsers; if so, click the canvas once to start playback. Your API key stays in your browser session.
</div>
""", unsafe_allow_html=True)